SCRIPT WIZARD - CONFLUENCE UPLOAD PACKAGE
=========================================

CONTENTS
  pages/   3 Confluence storage-format pages (paste these into Confluence)
  images/  diagram images to attach to the pages (SVG = primary, PNG = fallback)

These pages are in CONFLUENCE STORAGE FORMAT (XHTML). Do NOT just open the .html
in a browser - it will look plain and the diagrams/panels won't show. They only
render correctly INSIDE Confluence.

----------------------------------------------------------------------
PUBLISH ORDER (do this for EACH of the 3 pages)
----------------------------------------------------------------------
Suggested page order / hierarchy in Confluence:
   1. Script Wizard - Introduction              (pages/01-introduction.html)
   2. Script Wizard - High-Level Architecture   (pages/02-high-level-architecture.html)
   3. Script Wizard - Detailed Architecture     (pages/03-detailed-architecture-and-setup.html)

STEP 1 - Create the page and paste the content
   a) In Confluence: Create -> blank page. Give it the title above.
   b) Open the storage-format editor:
        Click the ... (More actions) menu  ->  Advanced  ->  "Storage format"
        (Some versions: the "<>" / source view in the editor.)
   c) Open the matching file in pages/ with Notepad, select ALL, copy.
   d) Paste into the storage-format box and Apply / Save.
   The headings, table of contents, coloured panels and tables now render.
   The diagrams will show as BROKEN/EMPTY until you attach the images (Step 2).

STEP 2 - Attach the diagram images to that page
   a) On the same page: ... (More actions) -> Attachments
        (or edit the page -> Insert -> Files -> Upload).
   b) Upload the SVG files from images/ that this page uses (list below).
      The attachment FILENAME must match exactly (e.g. 01-system-context.svg).
   c) Save. The <ac:image> references resolve to the attachments and the
      diagrams appear inline.

   If your Confluence does not render SVG attachments, attach the matching
   .png instead AND edit each page's image reference to end in .png
   (change  ri:filename="NAME.svg"  to  ri:filename="NAME.png"  in Step 1's paste).

----------------------------------------------------------------------
WHICH IMAGES EACH PAGE NEEDS
----------------------------------------------------------------------
01-introduction.html
   01-system-context, 03-value-flow, 02-capability-overview

02-high-level-architecture.html
   01-system-context, 11-dataflow-conceptual, 10-container

03-detailed-architecture-and-setup.html
   01-system-context, 10-container, 41-component-executor,
   20-job-submit-flow, 21-dispatch-flow, 22-sequence-sync-job,
   23-sequence-async-callback, 24-sequence-admin-login,
   31-job-state, 32-schedule-state
   (Tip: you can just attach ALL images to every page - extra attachments are harmless.)

----------------------------------------------------------------------
ALTERNATIVE - REST API (for an admin who prefers scripting)
----------------------------------------------------------------------
   Create/Update page with body.storage.value = file contents and
   body.storage.representation = "storage", then POST each image to the
   page's /child/attachment endpoint. Filenames must match the references.

Notes:
  * &nbsp; &middot; &mdash; etc. are standard entities Confluence accepts.
  * Cross-page links ("Related pages") are plain text - re-point them to your
    real Confluence page URLs after publishing if you want them clickable.
