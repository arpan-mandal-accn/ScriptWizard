SCRIPT WIZARD - CONFLUENCE UPLOAD PACKAGE
=========================================

CONTENTS
  publish_to_confluence.ps1   automated publisher (PowerShell 7+) - EASIEST
  pages\                       3 Confluence storage-format pages
  images\                      diagram images (SVG primary, PNG fallback)

The pages are CONFLUENCE STORAGE FORMAT (XHTML). Opening the .html in a browser
shows plain text with no diagrams - that is normal. They only render INSIDE
Confluence.

======================================================================
OPTION A (RECOMMENDED) - automated publish via REST API
======================================================================
Use this when the Confluence editor has NO "Source Editor" option.

  1. Install / open PowerShell 7  (run 'pwsh'; check $PSVersionTable.PSVersion = 7.x).
  2. Extract this zip and 'cd' into the extracted folder (where this script sits).
  3. Get a Personal Access Token (PAT):
        Confluence -> your avatar (top-right) -> Settings
        -> Personal Access Tokens -> Create token  -> copy it.
  4. Run:
        .\publish_to_confluence.ps1 -Token "<your-PAT>"

  It creates (or updates) all 3 pages under the GenWizard parent (space EAST,
  parent id 334792002) AND attaches each page's diagrams. Re-running UPDATES the
  pages (no duplicates). It prints each page's URL at the end.

  Variations:
    # username + password instead of a token:
    .\publish_to_confluence.ps1 -UseBasic -User "you@cardinalhealth.com"

    # if Confluence won't render SVG, publish PNGs (auto-rewrites refs to .png):
    .\publish_to_confluence.ps1 -Token "<PAT>" -ImageType png

    # different space / parent:
    .\publish_to_confluence.ps1 -Token "<PAT>" -SpaceKey EAST -ParentId <pageId>

  Troubleshooting:
    * "needs PowerShell 7+"     -> you launched old 'powershell'; start 'pwsh'.
    * 401 / 403                 -> bad/expired PAT, or no create-page rights in the space.
    * TLS / certificate error   -> corporate proxy; run from a machine that trusts
                                   the internal CA, or tell IT the REST endpoint.
    * page already exists        -> fine; the script updates it (version bump).

======================================================================
OPTION B - manual paste (only if your editor HAS a Source Editor)
======================================================================
  For each page:
   1. Create -> blank page, set the title (see list below).
   2. ... (More actions) -> Advanced -> "Storage format" / "Source Editor".
   3. Open the matching file in pages\ with Notepad, Select All, Copy, Paste, Save.
   4. On the page: ... -> Attachments -> upload that page's images (exact filenames).

  Page titles:
    Script Wizard - Introduction            pages-introduction.html
    Script Wizard - High-Level Architecture pages-high-level-architecture.html
    Script Wizard - Detailed Architecture   pages-detailed-architecture-and-setup.html

======================================================================
WHICH IMAGES EACH PAGE NEEDS  (Option A does this automatically)
======================================================================
01-introduction.html
   01-system-context, 03-value-flow, 02-capability-overview
02-high-level-architecture.html
   01-system-context, 11-dataflow-conceptual, 10-container
03-detailed-architecture-and-setup.html
   01-system-context, 10-container, 41-component-executor, 20-job-submit-flow,
   21-dispatch-flow, 22-sequence-sync-job, 23-sequence-async-callback,
   24-sequence-admin-login, 31-job-state, 32-schedule-state
  (Tip for manual mode: attaching ALL images to every page is harmless.)

Note: the "Related pages" links are plain text - re-point them to the real
Confluence URLs after publishing if you want them clickable.
