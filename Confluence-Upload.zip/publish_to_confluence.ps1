<#
  Publish the Script Wizard design docs to Confluence via the REST API.

  Run this from INSIDE the extracted Confluence-Upload folder. It expects the zip's
  layout next to this script:
      .\publish_to_confluence.ps1
      .\pages\01-introduction.html
      .\pages\02-high-level-architecture.html
      .\pages\03-detailed-architecture-and-setup.html
      .\images\*.svg  (+ *.png fallbacks)

  It creates (or updates) the 3 storage-format pages under a parent page and
  attaches each page's diagram images. No Source Editor needed.

  REQUIREMENTS
    * PowerShell 7+  (run with  pwsh , not the old  powershell ).
        Check:  $PSVersionTable.PSVersion   ->  must be 7.x
    * A Confluence account that can create pages in the target space, and a
      Personal Access Token (PAT):
        Confluence -> avatar (top-right) -> Settings -> Personal Access Tokens -> Create token
      (No PAT option? use -UseBasic for username+password.)

  USAGE  (open PowerShell 7, cd into the extracted folder):
    # 1. token auth (recommended)
    .\publish_to_confluence.ps1 -Token "<your-PAT>"

    # 2. basic auth (username + password)
    .\publish_to_confluence.ps1 -UseBasic -User "you@cardinalhealth.com"

    # 3. use PNG diagrams instead of SVG (if Confluence won't render SVG):
    .\publish_to_confluence.ps1 -Token "<PAT>" -ImageType png
       (also flips each page's image references from .svg to .png automatically)

  The space key (EAST) and parent page id (the GenWizard page) below match the
  editor URL you were on; override with -SpaceKey / -ParentId if needed.
#>
[CmdletBinding()]
param(
  [string]$BaseUrl   = "https://confluence.cardinalhealth.com",
  [string]$SpaceKey  = "EAST",
  [string]$ParentId  = "334792002",          # GenWizard page (parent). "" = create at space root.
  [ValidateSet("svg","png")]
  [string]$ImageType = "svg",
  [string]$Token,                             # Personal Access Token (preferred)
  [switch]$UseBasic,                          # use username/password instead of a token
  [string]$User
)

$ErrorActionPreference = "Stop"

# --- run from the script's own folder so relative pages\ / images\ always resolve
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
$pagesDir  = Join-Path $root "pages"
$imagesDir = Join-Path $root "images"
if (-not (Test-Path $pagesDir))  { throw "Can't find .\pages  - run this from the extracted Confluence-Upload folder." }
if (-not (Test-Path $imagesDir)) { throw "Can't find .\images - run this from the extracted Confluence-Upload folder." }

if ($PSVersionTable.PSVersion.Major -lt 7) {
  throw "This script needs PowerShell 7+ (multipart upload). You're on $($PSVersionTable.PSVersion). Start 'pwsh' and re-run."
}

$rest = "$BaseUrl/rest/api"

# --- pages and the images each one uses ---------------------------------------
$pages = @(
  @{ Title = "Script Wizard - Introduction";
     File  = "01-introduction.html";
     Images = @("01-system-context","03-value-flow","02-capability-overview") },
  @{ Title = "Script Wizard - High-Level Architecture";
     File  = "02-high-level-architecture.html";
     Images = @("01-system-context","11-dataflow-conceptual","10-container") },
  @{ Title = "Script Wizard - Detailed Architecture";
     File  = "03-detailed-architecture-and-setup.html";
     Images = @("01-system-context","10-container","41-component-executor",
                "20-job-submit-flow","21-dispatch-flow","22-sequence-sync-job",
                "23-sequence-async-callback","24-sequence-admin-login",
                "31-job-state","32-schedule-state") }
)

# --- auth header --------------------------------------------------------------
if ($UseBasic) {
  if (-not $User) { $User = Read-Host "Confluence username" }
  $sec  = Read-Host "Password" -AsSecureString
  $pwd  = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
            [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec))
  $pair = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("$User`:$pwd"))
  $authHeader = "Basic $pair"
} else {
  if (-not $Token) { $Token = Read-Host "Personal Access Token" }
  $authHeader = "Bearer $Token"
}
$headers = @{ Authorization = $authHeader }

function Get-PageByTitle($title) {
  $u = "$rest/content?spaceKey=$SpaceKey&title=$([uri]::EscapeDataString($title))&expand=version"
  $r = Invoke-RestMethod -Uri $u -Headers $headers -Method Get
  if ($r.results.Count -gt 0) { return $r.results[0] }
  return $null
}

function Publish-Page($p) {
  Write-Host "`n=== $($p.Title) ===" -ForegroundColor Cyan
  $file = Join-Path $pagesDir $p.File
  if (-not (Test-Path $file)) { throw "Missing page file: $file" }
  $storage = Get-Content -Raw -Encoding UTF8 $file

  # If publishing PNGs, point the image references at .png so they resolve to the
  # .png attachments we upload below.
  if ($ImageType -eq "png") { $storage = $storage -replace '\.svg"', '.png"' }

  $body = @{
    type  = "page"
    title = $p.Title
    space = @{ key = $SpaceKey }
    body  = @{ storage = @{ value = $storage; representation = "storage" } }
  }
  if ($ParentId) { $body.ancestors = @(@{ id = $ParentId }) }

  $existing = Get-PageByTitle $p.Title
  if ($existing) {
    $body.version = @{ number = ([int]$existing.version.number + 1) }
    $json = $body | ConvertTo-Json -Depth 12
    $page = Invoke-RestMethod -Uri "$rest/content/$($existing.id)" -Headers $headers `
              -Method Put -ContentType "application/json" -Body $json
    Write-Host "  updated page id $($page.id)" -ForegroundColor Yellow
  } else {
    $json = $body | ConvertTo-Json -Depth 12
    $page = Invoke-RestMethod -Uri "$rest/content" -Headers $headers `
              -Method Post -ContentType "application/json" -Body $json
    Write-Host "  created page id $($page.id)" -ForegroundColor Green
  }

  foreach ($name in $p.Images) {
    $img = Join-Path $imagesDir "$name.$ImageType"
    if (-not (Test-Path $img)) { Write-Host "  ! missing image $img" -ForegroundColor Red; continue }
    $u = "$rest/content/$($page.id)/child/attachment"
    try {
      # PS7 multipart upload; X-Atlassian-Token: no-check satisfies XSRF protection.
      Invoke-RestMethod -Uri $u -Method Post `
        -Headers ($headers + @{ "X-Atlassian-Token" = "no-check" }) `
        -Form @{ file = Get-Item $img; minorEdit = "true" } | Out-Null
      Write-Host "  attached $name.$ImageType"
    } catch {
      Write-Host "  ! attach failed for $name.$ImageType : $($_.Exception.Message)" -ForegroundColor Red
    }
  }
  Write-Host "  view: $BaseUrl/pages/viewpage.action?pageId=$($page.id)"
}

foreach ($p in $pages) { Publish-Page $p }
Write-Host "`nDone. Open each page; diagrams render from the attachments." -ForegroundColor Green
